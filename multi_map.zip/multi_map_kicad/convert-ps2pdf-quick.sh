#!/bin/sh
 pdfmerge multi_map.pdf\
 multi_map-SilkSCmp.pdf\
 multi_map-SilkSCop.pdf\
 multi_map-Component.pdf\
 multi_map-Copper.pdf\
 multi_map-SoldPCmp.pdf\
 multi_map-SoldPCop.pdf\
 layout.pdf

